package com.appsdeveloperblog.app.ws.exception;

public class UserServiceException extends RuntimeException {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6560935729306156014L;

	public UserServiceException(String message) {
		
		super(message);
	}
}
