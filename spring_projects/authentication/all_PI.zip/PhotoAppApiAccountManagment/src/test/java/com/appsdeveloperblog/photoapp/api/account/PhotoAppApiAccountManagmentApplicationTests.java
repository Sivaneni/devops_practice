package com.appsdeveloperblog.photoapp.api.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppApiAccountManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
